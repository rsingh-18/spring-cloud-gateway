package com.rohit.springgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringgatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
