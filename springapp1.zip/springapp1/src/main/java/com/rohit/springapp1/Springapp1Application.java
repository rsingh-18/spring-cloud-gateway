package com.rohit.springapp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springapp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springapp1Application.class, args);
	}

}
